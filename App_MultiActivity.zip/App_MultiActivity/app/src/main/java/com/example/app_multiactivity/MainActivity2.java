package com.example.app_multiactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView mediaFinalView, condicaoView, nomeView;
    String condicao, nome;
    Double mediaFinal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mediaFinalView = findViewById(R.id.textViewMedia);
        condicaoView = findViewById(R.id.textViewCondicao);
        nomeView = findViewById(R.id.textViewNome);

        Intent it = getIntent();

        if (it != null){
            Bundle params = it.getExtras();
            if (params != null){
                nome = params.getString("nome");
                mediaFinal = params.getDouble("mediaFinal");
                condicao = params.getString("condicao");

                nomeView.setText(nome);
                mediaFinalView.setText(String.valueOf(String.format("%.2f", mediaFinal)));
                condicaoView.setText(condicao);
            }
        }
    }
}