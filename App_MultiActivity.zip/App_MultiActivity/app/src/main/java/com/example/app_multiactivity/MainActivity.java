package com.example.app_multiactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText nomeText, nota1Text, nota2Text, frequenciaText;
    Double nota1, nota2, mediaFinal;
    int frequencia;
    String nome, nota1String, nota2String, frequenciaString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nomeText = findViewById(R.id.editTextName);
        nota1Text = findViewById(R.id.editTextNota1);
        nota2Text = findViewById(R.id.editTextNota2);
        frequenciaText = findViewById(R.id.editTextFrequencia);

    }

    public void calcula(View view) {

        nome = nomeText.getText().toString();
        nota1String = nota1Text.getText().toString();
        nota2String = nota2Text.getText().toString();
        frequenciaString = frequenciaText.getText().toString();

        if (nome.isEmpty() || nota1String.isEmpty() || nota2String.isEmpty() || frequenciaString.isEmpty()) {
            Toast.makeText(this, "Preencha todos os dados", Toast.LENGTH_SHORT).show();
        } else {
            nota1 = Double.parseDouble(nota1String);
            nota2 = Double.parseDouble(nota2String);
            frequencia = Integer.parseInt(frequenciaString);

            if (nota1 > 10 || nota2 > 10 || frequencia > 100) {
                Toast.makeText(this, "Preencha corretamente os dados", Toast.LENGTH_SHORT).show();
            } else {
                mediaFinal = (nota1 + nota2) / 2;

                Intent it = new Intent(this, MainActivity2.class);
                Bundle params = new Bundle();

                params.putString("nome", nome);
                params.putDouble("mediaFinal", mediaFinal);

                if (frequencia >= 75) {
                    if (mediaFinal >= 4) {
                        if (mediaFinal >= 7) {
                            params.putString("condicao", "APROVADO");
                        } else {
                            params.putString("condicao", "FINAL");
                        }
                    } else {
                        params.putString("condicao", "REPROVADO POR NOTA");
                    }
                } else {
                    params.putString("condicao", "REPROVADO POR FREQUÊNCIA");
                }

                it.putExtras(params);
                startActivity(it);
            }

        }

    }
}